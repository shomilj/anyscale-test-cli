# CreateBYODAppConfigConfigurationSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**docker_image** | **str** | The custom docker image to use to create a new app config. | 
**ray_version** | **str** |  | 
**env_vars** | [**object**](.md) | Environment variables in the docker image that&#39;ll be used at runtime. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


