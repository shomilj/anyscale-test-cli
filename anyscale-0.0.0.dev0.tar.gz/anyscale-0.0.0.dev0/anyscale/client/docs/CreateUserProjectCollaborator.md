# CreateUserProjectCollaborator

Fields that can be modified after writing
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permission_level** | [**PermissionLevel**](PermissionLevel.md) |  | 
**value** | [**CreateUserProjectCollaboratorValue**](CreateUserProjectCollaboratorValue.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


