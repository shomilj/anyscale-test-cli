# SessionStartingUpData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startup_progress** | **str** |  | [optional] 
**startup_error** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


