# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detail** | **object** |  | [optional] 
**body** | **object** |  | [optional] 
**message** | **str** | User friendly message that the UI can choose to display. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


