# LogDownloadResult

The result from a call to /logs/get_log_files.     
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_chunks** | [**list[LogFileChunk]**](LogFileChunk.md) | A list of log file chunks. | 
**next_page_token** | **str** | Next page token. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


