# MiniUser

The greatest common factor for user data across most endpoints of the API server
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The user id | 
**name** | **str** | The user&#39;s name | 
**username** | **str** | The username | 
**email** | **str** | The email | 
**lastname** | **str** | The user&#39;s last name. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


