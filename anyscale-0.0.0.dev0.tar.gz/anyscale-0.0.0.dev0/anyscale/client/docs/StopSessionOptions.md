# StopSessionOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminate** | **bool** |  | 
**workers_only** | **bool** |  | 
**keep_min_workers** | **bool** |  | 
**delete** | **bool** |  | [optional] [default to False]
**take_snapshot** | **bool** |  | [optional] [default to False]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


