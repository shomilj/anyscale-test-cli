# JobsLogsQueryInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loki_dns_name** | **str** | The DNS name for loki endpoint. | 
**loki_query** | **str** | The constructed loki query for a given job. | 
**access_token** | **str** | The token required to query Loki. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


