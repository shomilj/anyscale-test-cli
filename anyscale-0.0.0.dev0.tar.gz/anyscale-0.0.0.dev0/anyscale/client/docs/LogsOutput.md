# LogsOutput

This logs output type is used to model logs where line number is used to support pagination.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lines** | **str** |  | 
**num_lines** | **int** |  | 
**start_line** | **int** |  | 
**finished** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


